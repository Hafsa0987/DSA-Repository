#include<iostream>
using namespace std;
int main()
{
	int array[5]={23,12,14,19,34};
	int minVal=array[0];
	int size=5;
	for(int i=1;i<size;i++)
	{
		if(array[i]<minVal)
		{
			minVal=array[i];
		}
	}
	cout<<"The minimum number is "<<minVal<<endl;
	return 0;
}