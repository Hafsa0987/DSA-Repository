#include<iostream>
using namespace std;
int main()
{
	//intializing an array
	int size=5;
	int array[5]={04,10,28,19,22};
	//for printing array
	cout<<"The array elements are "<<endl;
	for(int i=0; i<size;i++)
	{
		cout<<array[i]<<" ";
	}
	return 0;
}