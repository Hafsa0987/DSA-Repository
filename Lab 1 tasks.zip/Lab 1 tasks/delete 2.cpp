#include <iostream> 

using namespace std; 
int main() 
{
int del; int count=0; 
int array[10],size; 
cout<<"Enter the size of your array:"; 
cin>>size; 
cout<<"Enter the elements of array"<<endl;
for(int i=0;i<size; i++) 
{ 
cin>>array[i];
} 
cout<<"Enter the number to delete"<<endl; 
cin>>del; 
for (int i=0; i<size; i++) 
{ 
if(array[i]==del) 
{ 
for (int j=i; j<(size-1); j++) 
{ 
array[j]=array[j+1]; 
} 
count++; 
break; 
} } 
if(count==0) { 
cout<<"Element not found...!!"; 
} 
else { 
cout<<"Element deleted successfully...!!\n"; cout<<"Now the new array is :\n"; 
for(int i=0; i<(size-1); i++) 
{ 
cout<<array[i]<<" "; 
} 
} 
return 0;} 


