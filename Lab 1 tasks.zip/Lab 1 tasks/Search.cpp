#include <iostream>
using namespace std;
int main()
{
	int size;
	cout<<"Enter the size of elements"<<endl;
	cin>>size;
	int inputArray[size];
	cout<<"Enter the "<<size<<"elements"<<endl;
	for(int i=0; i<size;i++)
	{
		cin>>inputArray[i];
	}
	int num;
	cout<<"Enter the number to be searched"<<endl;
	cin>>num;
	for(int i=0;i<size;i++)
	{
		bool found ;
    for (int i = 0; i < size; i++) {
        if (inputArray[i] == num) {
            cout << "Element found at index " << i << endl;
            found = true;
            break; 
        }
    }

    if (!found) {
        cout << "Element not present" << endl;
        found=false;
    }

		return 0;
	}
	
}