#include<iostream>
using namespace std;
int main()
{
	int size=5;
	int total=0;
	string salsa[size]={"mild","medium","sweet","hot","zesty"};
	int sales[size];
	for(int i=0;i<size;i++)
	{
		do{
			cout<<"Enter jars sold for " << salsa[i] <<endl;
			cin>>sales[i];
			if(sales[i]<0)
			{
				cout<<"invalid input! jars cannot be negative"<<endl;
			}	
		}
		while(sales[i]<0);
		{
			total=total+sales[i];
		}
	}
	int highestIndex = 0;
	int lowestIndex = 0;
    for (int i = 1; i < size; i++) {
        if (sales[i] > sales[highestIndex]) {
            highestIndex = i;
        }
        if (sales[i] < sales[lowestIndex]) {
            lowestIndex = i;
        }
    }
    
    cout << ".... Salsa Sales Report.... "<<endl;
    for (int i = 0; i < size; i++) {
        cout << salsa[i] << ": " << sales[i] << " jars"<<endl;
    }
   
    cout << "Total Sales: " << total << " jars"<<endl;
    cout << "Highest Selling: " << salsa[highestIndex] 
         << " (" << sales[highestIndex] << " jars)"<<endl;
    cout << "Lowest Selling: " << salsa[lowestIndex] 
         << " (" << sales[lowestIndex] << " jars)"<<endl;

    return 0;
}
	
