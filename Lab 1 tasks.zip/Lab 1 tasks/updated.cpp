#include<iostream>
using namespace std;
int main()
{
int index;
int students[5]={1,2,3,4,5};
	cout<<"The original elements are"<<endl;
for(int i=0;i<5;i++)
{
	cout<<students[i];	
}
cout<<"Enter the index on which you want to update a value"<<endl;
cin>>index;

if (index < 0 || index > 4) {
        cout << "Invalid index" << endl;
        return 1;
    }
cout<<"Enter the updated value"<<endl;
cin>>students[index];
cout << "The array after updating is: ";
    for (int i = 0; i <5; i++) {
        cout << students[i] << " ";
    }
    cout << endl;
    return 0;
}

