#include<iostream>
using namespace std;
int main()
{
int index;
int students[6]={1,2,3,4,5};
	cout<<"The original elements are"<<endl;
for(int i=0;i<5;i++)
{
	cout<<students[i];	
}
cout<<"Enter the position on which you want to give value"<<endl;
cin>>index;
if (index < 0 || index > 4) {
        cout << "Invalid index" << endl;
        return 1;
    }
int value;
cout<<"Enter the value  you want to insert"<<endl;
cin>>value;
for(int i=5;i>index;i--)
{
	students[i]=students[i-1];
}
students[index]=value;
cout<<"the value after insertion is "<<endl;
for(int i=0;i<6;i++)
{
 cout << students[i] << " ";
}
return 0;
}