#include<iostream>
using namespace std;
int main()
{
	//declaring an array
	int array[5];
    // Taking array elements from the user 
    int size;
    cout<<"Enter the size of elements"<<endl;
    cin>>size;
	cout<<"Enter "<< size<<" elements"<<endl;
	for(int i=0; i<size;i++)
	{
		cin>>array[i];
	}
	//for printing an array
	cout<<"The array elements are"<<endl;
	for(int i=0; i<size;i++)
	{
		cout<<array[i]<<" ";
	}
	return 0;
}