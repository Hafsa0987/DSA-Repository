#include<iostream>
using namespace std;
int main()
{
	int students[3];
	cout<<"Enter the marks of students"<<endl;
	for (int i=0;i<3;i++)
	{
		
		cin>>students[i];
		
	}
		for (int j=0;j<3;j++)
		{
		cout<<"Students"<<j<<"scored"<<students[j]<<"marks"<<endl;	
		}
		return 0;
}