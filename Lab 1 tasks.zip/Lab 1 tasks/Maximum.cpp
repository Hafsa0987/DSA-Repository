#include<iostream>
using namespace std;
int main()
{
	int array[5]={23,12,14,19,34};
	int maxVal=array[0];
	int size=5;
	for(int i=1;i<size;i++)
	{
		if(array[i]>maxVal)
		{
			maxVal=array[i];
		}
	}
	cout<<"The maximum number is "<<maxVal<<endl;
	return 0;
}