#include <iostream>
using namespace std;

int main() {
    struct Node {
        int data;
        Node* next;
    };

    // Create nodes
    Node* n1 = new Node();
    Node* n2 = new Node();
    Node* n3 = new Node();
    Node* n4 = new Node();

    n1->data = 10;
    n2->data = 20;
    n3->data = 30;
    n4->data = 40;

    // Linking nodes
    n1->next = n2;
    n2->next = n3;
    n3->next = n4;
    n4->next = NULL;
    Node* head = n1;
    
    Node *nn1=new Node();
    cout<<"Enter the value you want to insert"<<endl;
   cin>>nn1->data;
    nn1->next =n4;// nn1 points to n4
    n3->next = nn1;   // n3 points to nn1 instead of n4
    // Print updated list

    
    head = n1;
    while (head != NULL) {
        cout << head->data << " ";
        head = head->next;
    }

    return 0;
}
