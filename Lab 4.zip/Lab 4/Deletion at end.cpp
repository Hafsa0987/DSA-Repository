#include <iostream>
using namespace std;

int main() {
    struct Node {
        int data;
        Node* next;
    };

    // Create nodes
    Node* n1 = new Node();
    Node* n2 = new Node();
    Node* n3 = new Node();
    Node* n4 = new Node();

    n1->data = 10;
    n2->data = 20;
    n3->data = 30;
    n4->data = 40;

    // Linking nodes
    n1->next = n2;
    n2->next = n3;
    n3->next = n4;
    n4->next = NULL;

    Node* head = n1;

    cout << "Array before deletion" << endl;
    Node* temp = head;
    while (temp != NULL) {
        cout << temp->data << " ";
        temp = temp->next;
    }
    cout << endl;

    // ? Delete last node
    temp = head;
    while (temp->next->next != NULL) {   // stop at 2nd last node
        temp = temp->next;
    }
    delete(temp->next);   // delete last node
    temp->next = NULL;    // set new end

    cout << "Array after deletion" << endl;
    temp = head;
    while (temp != NULL) {
        cout << temp->data << " ";
        temp = temp->next;
    }
    cout << endl;

    return 0;
}
