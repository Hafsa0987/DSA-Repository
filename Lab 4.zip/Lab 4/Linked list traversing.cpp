#include<iostream>
using namespace std;
 int main()
 {
 	struct node{
 		int data;
 		node *next;
	 };
	
	 node* n1=new node();
	 node* n2=new node();
	 node* n3=new node();
	 n1->data=10;
	 n2->data=20;
	 n3->data=30;
	 n1->next=n2;
	 n2->next=n3;
	 n3->next=NULL;
	 cout<<".......Traversing......."<<endl;
	 node *head;
	 head=n1;
	 node* curr=head;
	 while(curr!=NULL)
	 {
	 	cout<<curr->data<<endl;
	 	curr=curr->next;
	 }
	 return 0;
 	
 }