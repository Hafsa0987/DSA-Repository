#include <iostream>
using namespace std;

struct Applicant {
    int applicant_id;
    float height;
    float weight;
    float eyesight;
    string status;
    Applicant* next;
    Applicant* prev;
};

class ApplicantQueue {
private:
    Applicant* front;
    Applicant* rear;

public:
    ApplicantQueue() { 
	front = nullptr;
	rear = nullptr; 
	}
//enqueue
    void enqueue(int id, float h, float w, float v, string s) {
        Applicant* newNode = new Applicant{id, h, w, v, s, nullptr, nullptr};
        if (rear == nullptr) {
            front = newNode;
			rear = newNode;
        } else {
            rear->next = newNode;
            newNode->prev = rear;
            rear = newNode;
        }
    }
//dequeue
    void dequeue() {
        if (front == nullptr) {
            cout << "Queue is empty!\n";
            return;
        }
        Applicant* temp = front;
        front = front->next;
        if (front) 
		{front->prev = nullptr;
		}
        else 
		rear = nullptr;
        delete temp;
    }
//
    void removeAtPosition(int pos) {
        if (front == nullptr) 
		return;
        Applicant* temp = front;
        int count = 1;

        while (temp != nullptr && count < pos) {
            temp = temp->next;
            count++;
        }
        if (temp == nullptr) 
		return;

        if (temp->prev) 
		{
		temp->prev->next = temp->next;
       } else 
	   {
	   	front = temp->next;
	   }
        if (temp->next) 
		{temp->next->prev = temp->prev;
		}
        else 
		{rear = temp->prev;
		}

        delete temp;
    }
//display
    void display() {
        if (!front) {
            cout << "Queue empty!\n";
            return;
        }
        Applicant* temp = front;
        cout << "\nCurrent Queue:\n";
        while (temp != nullptr) {
            cout << "ID: " << temp->applicant_id
                 << ", Height: " << temp->height
                 << ", Weight: " << temp->weight
                 << ", Vision: " << temp->eyesight
                 << ", Status: " << temp->status << endl;
            temp = temp->next;
        }
        cout << endl;
    }
};

int main() {
    ApplicantQueue q;

    // Initial 7 applicants
    q.enqueue(1, 5.8, 65, 6.0, "Pending");
    q.enqueue(2, 5.6, 60, 6.5, "Pending");
    q.enqueue(3, 5.9, 70, 6.0, "Pending");
    q.enqueue(4, 6.1, 80, 6.2, "Pending");
    q.enqueue(5, 5.5, 55, 5.8, "Pending");
    q.enqueue(6, 5.7, 68, 6.1, "Pending");
    q.enqueue(7, 6.1, 72, 6.3, "Pending");

    cout << "Initial Queue:\n";
    q.display();

    // 2nd person leaves suddenly
    cout << "\n2nd Applicant had urgency and left.\n";
    q.removeAtPosition(2);
    q.display();

    // Front person gives test
    cout << "\nFront applicant gives test and leaves.\n";
    q.dequeue();
    q.display();

    // New applicant joins at end
    cout << "\nNew applicant enters.\n";
    q.enqueue(8, 5.9, 69, 6.2, "Pending");
    q.display();

    return 0;
}
