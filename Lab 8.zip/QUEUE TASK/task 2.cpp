#include <iostream>
#include <queue>
#include <stack>
#include <string>
using namespace std;

class GarageSystem {
private:
    queue<int> road;     // trucks waiting on the road
    stack<int> garage;   // trucks inside the garage

public:
    //  On_road(truck_id)
    void On_road(int truck_id) {
        road.push(truck_id);
        cout << "Truck " << truck_id << " is now on the road.\n";
    }

    //  Enter_garage(truck_id)
    void Enter_garage(int truck_id) {
        if (road.empty()) {
            cout << "No trucks on the road to enter garage.\n";
            return;
        }

        // Check if the front of road matches
        if (road.front() == truck_id) {
            road.pop();
            garage.push(truck_id);
            cout << "Truck " << truck_id << " entered the garage.\n";
        } else {
            cout << "Truck " << truck_id << " is not at front of the road queue.\n";
        }
    }

    //  Exit_garage(truck_id)
    void Exit_garage(int truck_id) {
        if (garage.empty()) {
            cout << "Garage is empty!\n";
            return;
        }

        if (garage.top() == truck_id) {
            garage.pop();
            cout << "Truck " << truck_id << " exited the garage.\n";
        } else {
            cout << "Error: Truck " << truck_id << " is not near the garage door!\n";
        }
    }

    // Show_trucks(area)
    void Show_trucks(string area) {
        if (area == "road") {
            if (road.empty()) {
                cout << "No trucks on the road.\n";
                return;
            }
            cout << "Trucks on road: ";
            queue<int> temp = road;
            while (!temp.empty()) {
                cout << temp.front() << " ";
                temp.pop();
            }
            cout << endl;
        } 
        else if (area == "garage") {
            if (garage.empty()) {
                cout << "No trucks in garage.\n";
                return;
            }
            cout << "Trucks in garage : ";
            stack<int> temp = garage;
            while (!temp.empty()) {
                cout << temp.top() << " ";
                temp.pop();
            }
            cout << endl;
        } 
        else {
            cout << "Invalid area. Use 'road' or 'garage'.\n";
        }
    }
};
int main() {
    GarageSystem system;

    // Trucks arrive on road
    system.On_road(2);
    system.On_road(5);
    system.On_road(10);
    system.On_road(9);
    system.On_road(22);

    cout << endl;
    system.Show_trucks("road");
    system.Show_trucks("garage");

    // Trucks entering garage
    cout << "\n--- Trucks Entering Garage ---\n";
    system.Enter_garage(2);
    
    system.Show_trucks("road");
    system.Show_trucks("garage");

    // Exit attempt
    cout << "\n--- Trucks Exiting Garage ---\n";
    system.Exit_garage(5); 
    system.Exit_garage(10);

    system.Show_trucks("garage");

    // New truck arrives and enters
    system.On_road(10);
    system.Enter_garage(5);
    system.Enter_garage(9);

    cout << "\n--- Final State ---\n";
    system.Show_trucks("road");
    system.Show_trucks("garage");

    return 0;
}
