#include <iostream>
using namespace std;

struct Node {
    int data;
    Node* prev;
    Node* next;
};

Node* head = NULL;

void deleteAtStart() {
   if (head == NULL) {
        cout << "List is empty, nothing to delete!" << endl;
        return;
    }
    
    Node* temp = head;
    head = head->next;  // Move head to next node

    if (head != NULL)
        head->prev = NULL;  // Set new head’s prev to NULL

    cout << "Deleted node with value: " << temp->data << endl;
    delete temp;
}
void display() {
    Node* temp = head;
    cout << "Doubly Linked List: ";
    while (temp != NULL) {
        cout << temp->data << " ";
        temp = temp->next;
    }
    cout << endl;
}

int main() {
    // Manually creating list: 10 <-> 20 <-> 30
    Node* first = new Node{10, NULL, NULL};
    Node* second = new Node{20, first, NULL};
    Node* third = new Node{30, second, NULL};
    first->next = second;
    second->next = third;
    head = first;

    cout << "Before deletion:\n";
    display();

    deleteAtStart();

    cout << "After deletion:\n";
    display();

    return 0;
}