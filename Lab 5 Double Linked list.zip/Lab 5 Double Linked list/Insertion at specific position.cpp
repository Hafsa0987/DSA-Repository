#include <iostream>
using namespace std;

struct Node {
    int data;
    Node* prev;
    Node* next;
};

Node* head = NULL;

void insertAtPosition(int pos, int val) {
    Node* newNode = new Node();
    newNode->data = val;
    newNode->prev = NULL;
    newNode->next = NULL;

    // Case 1: Insert at beginning
    if (pos == 1) {
        newNode->next = head;
        if (head != NULL)
            head->prev = newNode;
        head = newNode;
        return;
    }
    
    Node* temp = head;
    int count = 1;

    // Traverse to (pos - 1)th node
    while (temp != NULL && count < pos - 1) {
        temp = temp->next;
        count++;
    }

    // Case 2: Invalid position
    if (temp == NULL) {
        cout << "Position out of range!" << endl;
        delete newNode;
        return;
    }

    // Case 3: Insert in between or at end
    newNode->next = temp->next;
    newNode->prev = temp;

    if (temp->next != NULL)
        temp->next->prev = newNode;

    temp->next = newNode;
}

void display() {
    Node* temp = head;
    while (temp != NULL) {
        cout << temp->data << " ";
        temp = temp->next;
    }
    cout << endl;
}

int main() {
	cout<<"List before insertion: ";
    insertAtPosition(1, 10);
    insertAtPosition(2, 20);
    insertAtPosition(3, 30);
    display();
    cout<<"List after insertion: ";
    insertAtPosition(2, 15); // Insert 15 at position 2
    display();
    return 0;
}
