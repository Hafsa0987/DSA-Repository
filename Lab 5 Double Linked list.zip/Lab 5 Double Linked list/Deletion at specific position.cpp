#include <iostream>
using namespace std;

struct Node {
    int data;
    Node* prev;
    Node* next;
};

Node* head = NULL;

void deleteAtPosition(int pos) {
    if (head == NULL) {
        cout << "List is empty, nothing to delete!" << endl;
        return;
    }

    Node* temp = head;

    // Case 1: Delete first node
    if (pos == 1) {
        head = head->next;
        if (head != NULL)
            head->prev = NULL;
        cout << "Deleted node with value: " << temp->data << endl;
        delete temp;
        return;
    }

    int count = 1;
    while (temp != NULL && count < pos) {
        temp = temp->next;
        count++;
    }

    // Case 2: Invalid position
    if (temp == NULL) {
        cout << "Position out of range!" << endl;
        return;
    }

    // Adjust the pointers
    if (temp->next != NULL)
        temp->next->prev = temp->prev;

    if (temp->prev != NULL)
        temp->prev->next = temp->next;

    cout << "Deleted node with value: " << temp->data << endl;
    delete temp;
}

void display() {
    Node* temp = head;
    cout << "Doubly Linked List: ";
    while (temp != NULL) {
        cout << temp->data << " ";
        temp = temp->next;
    }
    cout << endl;
}

int main() {
    // Manually creating list: 10 <-> 20 <-> 30 <-> 40
    Node* n1 = new Node{10, NULL, NULL};
    Node* n2 = new Node{20, n1, NULL};
    Node* n3 = new Node{30, n2, NULL};
    Node* n4 = new Node{40, n3, NULL};
    n1->next = n2;
    n2->next = n3;
    n3->next = n4;
    head = n1;

    cout << "Before deletion:\n";
    display();

    deleteAtPosition(3);  // Delete node at position 3 (value 30)

    cout << "After deletion:\n";
    display();

    return 0;
}
