#include <iostream>
using namespace std;

struct Node {
    int data;
    Node* prev;
    Node* next;
};

// Function to insert at beginning of an existing list
void insertAtBeginning(Node*& head, int value) {
    Node* newNode = new Node;
    newNode->data = value;
    newNode->prev = nullptr;
    newNode->next = head; // Point new node's next to current head

    if (head != nullptr) { // If list is not empty
        head->prev = newNode; // Update current head's previous pointer
    }

    head = newNode; // Make new node the new head
}

// Function to print the list
void printList(Node* head) {
    Node* temp = head;
    while (temp != nullptr) {
        cout << temp->data << " ";
        temp = temp->next;
    }
    cout << endl;
}

int main() {
    // Suppose this list already exists:
    Node* head = new Node{10, nullptr, nullptr};
    head->next = new Node{20, head, nullptr};
    head->next->next = new Node{30, head->next, nullptr};

    cout << "Original list: ";
    printList(head);

    // Insert new node at beginning
    insertAtBeginning(head,5);

    cout << "After inserting 5 at beginning: ";
    printList(head);

    return 0;
}
