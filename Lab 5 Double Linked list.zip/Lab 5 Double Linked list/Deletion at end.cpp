#include <iostream>
using namespace std;
struct Node {
    int data;
    Node* prev;
    Node* next;
};
Node* head = NULL;
void deleteAtEnd() {
    if (head == NULL) {
        cout << "List is empty, nothing to delete!" << endl;
        return;
    }

    // Case 1: Only one node
    if (head->next == NULL) {
        cout << "Deleted node with value: " << head->data << endl;
        delete head;
        head = NULL;
        return;
    }

    // Case 2: More than one node
    Node* temp = head;
    while (temp->next != NULL)
        temp = temp->next;  // move to last node

    cout << "Deleted node with value: " << temp->data << endl;

    temp->prev->next = NULL;  // remove last node’s link from previous
    delete temp;
}

void display() {
    Node* temp = head;
    cout << "Doubly Linked List: ";
    while (temp != NULL) {
        cout << temp->data << " ";
        temp = temp->next;
    }
    cout << endl;
}

int main() {
    // Manually creating list: 10 <-> 20 <-> 30
    Node* first = new Node{10, NULL, NULL};
    Node* second = new Node{20, first, NULL};
    Node* third = new Node{30, second, NULL};
    first->next = second;
    second->next = third;
    head = first;

    cout << "Before deletion:\n";
    display();
    deleteAtEnd();

    cout << "After deletion:\n";
    display();

    return 0;
}
