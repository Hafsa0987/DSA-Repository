//question 3
//Declare an array of 5 integers and print tha first and last element using pointers.
#include<iostream>
using namespace std;
int main()
{
	int arr[5]={12,34,67,31,23};
	int* ptr=arr;
	cout<<"The first element is: "<< *ptr<<endl;
	cout<<"The last element is: "<<*(ptr+4)<<endl;
	return 0;
	
}