#include<iostream>
using namespace std;
int main()
{
	//question 1
	//Declare two integers and two pointers. use the pointer to add two integers and print result
	int a ,b;
	int *ptr1 , *ptr2;
	cout<<"Enter the fisrt integer "<<endl;
	cin>>a;
	cout<<"Enter the second integer "<<endl;
	cin>>b;
	//assign addresses to pointers
	ptr1=&a;
	ptr2=&b;
	//using pointers to add the values
    int sum =*ptr1+*ptr2;
	cout<<"The sum of two integers using pointers is: "	<<sum<<endl;
	return 0;
	
	
	
}