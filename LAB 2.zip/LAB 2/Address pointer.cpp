#include<iostream>
using namespace std;
int main()
{
	int num=20;

	cout<<"The value of num is "<<num<<endl;
	cout<<"The address of num is "<<&num<<endl;
	return 0;
}