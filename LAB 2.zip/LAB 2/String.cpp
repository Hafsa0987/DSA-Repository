#include<iostream>
using namespace std;
int main()
 {
    const char *str = "Hello World!";  
    cout << "The string is " << str << endl;
    cout << "The fisrt character of string is" << *str << endl;
    return 0;
}