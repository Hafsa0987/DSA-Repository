#include<iostream>
using namespace std;
int main()
{
	int *ptr= NULL;
	cout<<"value of pointer is "<< ptr<<endl;
	cout<<"Address of pointer is "<<&ptr<<endl;
	return 0;
}