//question 2
//Declare an integer variable and pointer to it. Use the pointer to modify the value of integer and the print the updated value.
#include<iostream>
using namespace std;
int main()
{
	int a;
	cout<<"Enter the integer"<<endl;
	cin>>a;
	int *ptr=&a;
	//modifying the vaulue using ptr
	*ptr=*ptr+10;
	cout<<"The updated value is: "<< *ptr<<endl;
	return 0;
}