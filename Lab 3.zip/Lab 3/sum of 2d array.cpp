#include<iostream>
using namespace std;
int main()
{
	int arr[4][4];
	int size=4;
	int sum=0;
	cout <<" Enter the number of rows and columns"<<endl;
	for(int i=0; i<size;i++)
	{
		for(int j=0; j<size;j++)
		{
		cin>>arr[i][j];
		sum=sum+arr[i][j];
	
	}
}


		cout<<" The sum is "<<sum<<endl;
	
return 0;	
}

