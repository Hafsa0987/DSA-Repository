#include<iostream>
using namespace std;
int main()
{
	int index;
	int size;
	cout<<"Enter the size of array "<<endl;
	cin>>size;
	//create dynamic array
	int *arr=new int[size];
	
	cout<<"Enter the "<<size<<" elements"<<endl;
	for(int i=0;i<size; i++)
	{
		cin>>arr[i];
	}
	//read
		cout<<"The original elements are"<<endl;
for(int i=0;i<size;i++)
{
	cout<<arr[i]<<" ";	

}
	//insertion
		cout<<"Enter the position on which you want to insert value"<<endl;
cin>>index;
if (index < 0 || index >= size) {
        cout << "Invalid index" << endl;
        return 1;
    }
int value;
cout<<"Enter the value  you want to insert"<<endl;
cin>>value;
for(int i=size;i>index;i--)
{
	arr[i]=arr[i-1];
}
arr[index]=value;
size++;
cout<<"the value after insertion is "<<endl;
for(int i=0;i<size;i++)
{
 cout << arr[i] << " ";

}

//Update
 cout<<"Enter the index on which you want to update a value"<<endl;
cin>>index;

if (index < 0 || index >= size) {
        cout << "Invalid index" << endl;
        return 1;
    }
cout<<"Enter the updated value"<<endl;
cin>>arr[index];
cout << "The array after updating is: ";
    for (int i = 0; i <size; i++) {
        cout <<arr[i] << " ";
    }
    cout << endl;


//Deletion 
cout << "Enter the index to delete : ";
    cin >> index;

    if (index < 0 || index >= size) {
        cout << "Invalid position!" << endl;
    } else {
       
        for (int i = index; i < size - 1; i++) {
            arr[i] = arr[i + 1];
        }
        size--;

        cout << "Array after deletion:\n";
        for (int i = 0; i < size; i++) {
            cout << arr[i] << " ";
        }
        cout << endl;
    }
    delete[] arr;
 

return 0;
}