#include <iostream>
#include <string>
using namespace std;

class Book {
public:
    string title;
    float price;
    int edition;
    int numberOfpages;

    // Default constructor (required for struct Node)
    Book() {}

    // Parameterized constructor
    Book(string t, float p, int ed, int no) {
        title = t;
        price = p;
        edition = ed;
        numberOfpages = no;
    }

    // Display function
    void display() {
        cout << "Title: " << title << endl;
        cout << "Price: " << price << endl;
        cout << "Edition: " << edition << endl;
        cout << "Number of Pages: " << numberOfpages << endl;
    }
};

// Node structure for Linked List
struct Node {
    Book data;
    Node* next;
};

// Stack class
class Stack {
private:
    Node* top;

public:
    Stack() {
        top = nullptr;
    }

    // Push function
    void push(string title, float price, int edition, int numberOfpages) {
        Node* newNode = new Node();
        newNode->data = Book(title, price, edition, numberOfpages);
        newNode->next = top;
        top = newNode;
        cout << "Book \"" << title << "\" pushed into stack.\n";
    }

    // Pop function
    void pop() {
        if (top == nullptr) {
            cout << "Stack is empty! Cannot pop.\n";
            return;
        }
        cout << "Book \"" << top->data.title << "\" popped from the stack.\n";
        Node* temp = top;
        top = top->next;
        delete temp;
    }

    // Peek (show top book)
    void peek() {
        if (top == nullptr) {
            cout << "Stack is empty.\n";
            return;
        }
        cout << "\nTop Book Details:\n";
        top->data.display();
    }

    // Display all books in the stack
    void display() {
        if (top == nullptr) {
            cout << "Stack is empty.\n";
            return;
        }

        cout << "\nBooks in the Stack:\n";
        Node* temp = top;
        while (temp != nullptr) {
            cout << "------------------------\n";
            temp->data.display();
            temp = temp->next;
        }
        cout << "------------------------\n";
    }
};

// Main function
int main() {
    Stack s1;

    s1.push("C++ Basics", 750, 2, 350);
    s1.push("Data Structures", 900, 3, 500);
    s1.push("Operating Systems", 1200, 4, 600);
    s1.push("Database Systems", 1100, 2, 550);
    s1.push("Computer Networks", 950, 1, 480);

    s1.peek();

    cout << "\n--- Popping 2 Books ---\n";
    s1.pop();
    s1.pop();

    s1.display();

    return 0;
}
