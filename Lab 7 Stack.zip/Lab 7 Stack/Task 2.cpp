#include<iostream>
using namespace std;
//inventory class
class Inventory{
public:
int serialNumber;
int manufactYear;
int LotNumber;
//default constructor
Inventory() {}
Inventory(int sr,int my,int Ln)
{
	serialNumber=sr;
	manufactYear=my;
	LotNumber=Ln;
}
void display()
{
	cout<<"Serial Number "<<serialNumber<<endl;
	cout<<"Manufacture year "<<manufactYear<<endl;
	cout<<"Lot Number "<<LotNumber<<endl;
}
};
//structure node
struct Node{
	Inventory data;
	Node* next;
};
//stack class
class stack
{
private:
	Node *top;
public:
	stack()
	{
		top = nullptr;
	}
~stack()
{
}
bool isEmpty() {
        return top == nullptr;
    }
    // push function
void push(Inventory item)
{
	Node *newNode= new Node();
	newNode->data=item;
	newNode->next=top;
	top=newNode;
}
//pop function
void pop(){
	  if (top == nullptr) {
            cout << "Stack is empty! Cannot pop.\n";
            return;
        }
    cout << "Popped items detail: \n";
    
        top->data.display();
        Node* temp = top;
        top = top->next;
        delete temp;
}
//Display All
void display() {
        if (top == nullptr) {
            cout << "Stack is empty.\n";
            return;
        }

        cout << "\n Items in the inventory:\n";
        Node* temp = top;
        while (temp != nullptr) {
            cout << "------------------------\n";
            temp->data.display();
            temp = temp->next;
        }
        cout << "------------------------\n";
    }
};
int main()
{
	stack inventoryStack;
	int choice;
    cout << "==========INVENTORY MANAGEMENT STACK========\n";
	do{
		cout << "\n1. Add a part to inventory (Push)";
        cout << "\n2. Take a part from inventory (Pop)";
        cout << "\n3. Exit";
        cout << "\nEnter your choice: ";
        cin >> choice;
        if (choice==1)
        {
        	int serial, year, lot;
        	cout<<"Enter the serial number"<<endl;
        	cin>>serial;
        	cout<<"Enter the manufacture year"<<endl;
        	cin>>year;
        	cout<<"Enter the lot number"<<endl;
        	cin>>lot;
        	Inventory item(serial, year, lot);
            inventoryStack.push(item);
            cout<<"Part added successfully"<<endl;
		}
		else if(choice==2)
		{
		inventoryStack.pop();
		}
		else if(choice==3)
		{
		cout<<"Existing program"<<endl;
	    inventoryStack.display();
		}
	 else
	 {
	 cout<<"Invalid choice! please try again....."<<endl;
	 }
	}while(choice!=3);
	return 0;
}