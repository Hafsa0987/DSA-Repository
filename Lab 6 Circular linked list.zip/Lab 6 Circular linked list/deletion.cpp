#include <iostream>
using namespace std;

struct Node {
    int data;
    Node* next;
};

// Function to create a new node
Node* createNode(int data) {
    Node* newNode = new Node();
    newNode->data = data;
    newNode->next = nullptr;
    return newNode;
}

// Helper function to display the list
void display(Node* head) {
    if (head == nullptr) {
        cout << "List is empty!\n";
        return;
    }
    Node* temp = head;
    do {
        cout << temp->data << " -> ";
        temp = temp->next;
    } while (temp != head);
    cout << "(back to head)\n";
}

// ---------------- DELETION FUNCTIONS ----------------

// Delete from start
void deleteFromStart(Node*& head) {
    if (head == nullptr) {
        cout << "List is empty!\n";
        return;
    }

    Node* temp = head;

    // If only one node
    if (head->next == head) {
        delete head;
        head = nullptr;
        return;
    }

    // Traverse to last node
    Node* last = head;
    while (last->next != head)
        last = last->next;

    head = head->next;
    last->next = head;
    delete temp;
    cout << "Node deleted from start.\n";
}

// Delete from end
void deleteFromEnd(Node*& head) {
    if (head == nullptr) {
        cout << "List is empty!\n";
        return;
    }

    // If only one node
    if (head->next == head) {
        delete head;
        head = nullptr;
        return;
    }

    Node* temp = head;
    Node* prev = nullptr;

    while (temp->next != head) {
        prev = temp;
        temp = temp->next;
    }

    prev->next = head;
    delete temp;
    cout << "Node deleted from end.\n";
}

// Delete from specific position
void deleteFromPosition(Node*& head, int position) {
    if (head == nullptr) {
        cout << "List is empty!\n";
        return;
    }

    if (position < 1) {
        cout << "Invalid position!\n";
        return;
    }

    // Deletion from start
    if (position == 1) {
        deleteFromStart(head);
        return;
    }

    Node* temp = head;
    Node* prev = nullptr;

    for (int i = 1; i < position; i++) {
        prev = temp;
        temp = temp->next;
        if (temp == head) {
            cout << "Position out of range!\n";
            return;
        }
    }

    prev->next = temp->next;
    delete temp;
    cout << "Node deleted from position " << position << ".\n";
}

// ---------------- MAIN FUNCTION ----------------
int main() {
    Node* head = nullptr;

    // Creating a simple circular linked list: 10 -> 20 -> 30 -> (back to head)
    Node* n1 = createNode(10);
    Node* n2 = createNode(20);
    Node* n3 = createNode(30);
    head = n1;
    n1->next = n2;
    n2->next = n3;
    n3->next = head;

    cout << "Initial list: ";
    display(head);

    deleteFromStart(head);
    display(head);

    deleteFromEnd(head);
    display(head);

    deleteFromPosition(head, 1);
    display(head);

    return 0;
}
