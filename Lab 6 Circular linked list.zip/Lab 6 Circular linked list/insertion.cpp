#include <iostream>
using namespace std;

struct Node {
    int data;
    Node* next;
};

// Function to create a new node
Node* createNode(int data) {
    Node* newNode = new Node();
    newNode->data = data;
    newNode->next = nullptr;
    return newNode;
}

// Insert at start
void insertAtStart(Node*& head, int data) {
    Node* newNode = createNode(data);
    if (head == nullptr) {
        head = newNode;
        newNode->next = head;
        return;
    }

    Node* temp = head;
    // Traverse to last node
    while (temp->next != head)
        temp = temp->next;

    newNode->next = head;
    temp->next = newNode;
    head = newNode;
}

// Insert at end
void insertAtEnd(Node*& head, int data) {
    Node* newNode = createNode(data);
    if (head == nullptr) {
        head = newNode;
        newNode->next = head;
        return;
    }

    Node* temp = head;
    while (temp->next != head)
        temp = temp->next;

    temp->next = newNode;
    newNode->next = head;
}

// Insert at specific position (1-based)
void insertAtPosition(Node*& head, int data, int position) {
    if (position < 1) {
        cout << "Invalid position!\n";
        return;
    }

    if (position == 1) {
        insertAtStart(head, data);
        return;
    }

    Node* newNode = createNode(data);
    Node* temp = head;

    for (int i = 1; i < position - 1; i++) {
        temp = temp->next;
        if (temp == head) {
            cout << "Position out of range!\n";
            return;
        }
    }

    newNode->next = temp->next;
    temp->next = newNode;
}

// Display circular linked list
void display(Node* head) {
    if (head == nullptr) {
        cout << "List is empty!\n";
        return;
    }
    Node* temp = head;
    do {
        cout << temp->data << " -> ";
        temp = temp->next;
    } while (temp != head);
    cout << "(back to head)\n";
}

// Main function
int main() {
    Node* head = nullptr;

    insertAtEnd(head, 10);
    insertAtEnd(head, 20);
    insertAtEnd(head, 30);
    cout << "Initial list: ";
    display(head);

    insertAtStart(head, 5);
    cout << "After insertion at start: ";
    display(head);

    insertAtEnd(head, 40);
    cout << "After insertion at end: ";
    display(head);

    insertAtPosition(head, 25, 4);
    cout << "After insertion at position 4: ";
    display(head);

    return 0;
}
