// C++ program for insertion and deletion in Circular Queue using Linked List
#include <iostream>
using namespace std;

struct Node {
    int data;
    Node* link;
};

struct Queue {
    Node* front;
    Node* rear;
};

// Function to insert element into Circular Queue
void enQueue(Queue* q, int value) {
    Node* temp = new Node();
    temp->data = value;
    temp->link = nullptr;

    // If queue is empty
    if (q->front == nullptr) {
        q->front = temp;
    } else {
        q->rear->link = temp;
    }

    q->rear = temp;
    q->rear->link = q->front; // make it circular
}

// Function to delete element from Circular Queue
int deQueue(Queue* q) {
    if (q->front == nullptr) {
        cout << "Queue is empty" << endl;
        return INT_MIN;
    }

    int value;

    // Only one node in queue
    if (q->front == q->rear) {
        value = q->front->data;
        delete q->front;
        q->front = q->rear = nullptr;
    }
    else { // More than one node
        Node* temp = q->front;
        value = temp->data;
        q->front = q->front->link;
        q->rear->link = q->front; // maintain circular link
        delete temp;
    }

    return value;
}

// Function to display the Circular Queue
void displayQueue(Queue* q) {
    if (q->front == nullptr) {
        cout << "\nQueue is empty" << endl;
        return;
    }

    Node* temp = q->front;
    cout << "\nElements in Circular Queue are: ";
    do {
        cout << temp->data << " ";
        temp = temp->link;
    } while (temp != q->front);
    cout << endl;
}

// Driver code
int main() {
    Queue q;
    q.front = q.rear = nullptr;

    // Inserting elements in Circular Queue
    enQueue(&q, 14);
    enQueue(&q, 22);
    enQueue(&q, 6);

    // Display elements present in Circular Queue
    displayQueue(&q);

    // Deleting elements from Circular Queue
    cout << "\nDeleted value = " << deQueue(&q);
    cout << "\nDeleted value = " << deQueue(&q);

    // Remaining elements in Circular Queue
    displayQueue(&q);

    enQueue(&q, 9);
    enQueue(&q, 20);
    displayQueue(&q);

    return 0;
}
