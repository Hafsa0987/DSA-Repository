#include<iostream>
using namespace std;
const int QUEUE_CAPACITY = 128;

class Queue
{

		int myArray[QUEUE_CAPACITY];
		int front,rear;
		int count;
	

public: Queue()
 {
 	front =rear=count=0;
 }
bool isEmpty()
 {
 	if(count==0)
 		return true;
 	else
 	return false;
 }
bool  isFull()
 {
 	if(count==QUEUE_CAPACITY)
 	return true;
 	else
 	return false;
 }
int getFront()
 {
 	if(!isEmpty())
 	{
 		return myArray[front];
	 }
	 else 
	 return -1;
 }
void enqueue(int value)
 {
 	if(! isFull())
 
 	{	
 		myArray[rear]=value;
 		rear=(rear+1)%QUEUE_CAPACITY;
 		count++;
 	cout<<" Enqueded"<<endl;
	 }
	 else cout<<" Queue Underflow";

 }
void dequeue()
 {
 	if(! isEmpty())
 
 	{	
 	int val=	myArray[front];
 		front=(front+1)%QUEUE_CAPACITY;
 		count--;
 	cout<<" Dequeded"<<endl;
	 }
	 else cout<<" Queue Underflow";

 }
void display()
{
    if (isEmpty())
    {
        cout << "Queue is empty\n";
        return;
    }

    cout << "Queue elements:\n";
    int p = front;
    for (int i = 0; i < count; i++)
    {
        cout << myArray[p] << " ";
        p = (p + 1) % QUEUE_CAPACITY;
    }
    cout << endl;
}


};
 int main()
 {
 
 	Queue q;
 	q.enqueue(2);
 	q.enqueue(4);
 	q.display();
 
//q.dequeue();
 	//	q.display();
 	
 	
 	return 0;
 }
