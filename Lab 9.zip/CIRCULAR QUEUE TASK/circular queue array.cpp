// C++ program for insertion and deletion in Circular Queue
#include <iostream>
#include <vector>
using namespace std;

class CircularQueue {
private:
    int size, front, rear;
    vector<int> queue;

public:
    // Constructor
    CircularQueue(int size) {
        this->size = size;
        this->front = this->rear = -1;
        queue.resize(size);
    }

    // Method to insert a new element in the queue
    void enQueue(int data) {
        // Condition if queue is full
        if ((front == 0 && rear == size - 1) ||
            (rear == (front - 1 + size) % size)) {
            cout << "Queue is Full" << endl;
            return;
        }

        // Condition for empty queue
        else if (front == -1) {
            front = rear = 0;
            queue[rear] = data;
        }

        else if (rear == size - 1 && front != 0) {
            rear = 0;
            queue[rear] = data;
        }

        else {
            rear = (rear + 1) % size;
            queue[rear] = data;
        }
    }

    // Function to dequeue an element
    int deQueue() {
        // Condition for empty queue
        if (front == -1) {
            cout << "Queue is Empty" << endl;
            return -1;
        }

        int temp = queue[front];

        // Condition for only one element
        if (front == rear) {
            front = rear = -1;
        }
        else if (front == size - 1) {
            front = 0;
        }
        else {
            front++;
        }

        return temp;
    }

    // Method to display the elements of queue
    void displayQueue() {
        if (front == -1) {
            cout << "Queue is Empty" << endl;
            return;
        }

        cout << "Elements in the circular queue are: ";

        if (rear >= front) {
            for (int i = front; i <= rear; i++)
                cout << queue[i] << " ";
        }
        else {
            for (int i = front; i < size; i++)
                cout << queue[i] << " ";
            for (int i = 0; i <= rear; i++)
                cout << queue[i] << " ";
        }
        cout << endl;
    }
};

// Driver code
int main() {
    CircularQueue q(5);

    q.enQueue(14);
    q.enQueue(22);
    q.enQueue(13);
    q.enQueue(-6);

    q.displayQueue();

    int x = q.deQueue();
    if (x != -1)
        cout << "Deleted value = " << x << endl;

    x = q.deQueue();
    if (x != -1)
        cout << "Deleted value = " << x << endl;

    q.displayQueue();

    q.enQueue(9);
    q.enQueue(20);
    q.enQueue(5);

    q.displayQueue();

    q.enQueue(20); // will show "Queue is Full"

    return 0;
}
